package com.quizgame.db;

import com.quizgame.db.DBConnection;
import com.quizgame.db.Question;
import java.sql.*;
import java.util.*;

public class QuizGame {
	Scanner sc = new Scanner(System.in);
    public void startQuiz() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM questions";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                String question = rs.getString("question");
                String A = rs.getString("option_a");
                String B = rs.getString("option_b");
                String C = rs.getString("option_c");
                String D = rs.getString("option_d");
                System.out.println(question);
                System.out.println("A: " + A);
                System.out.println("B: " + B);
                System.out.println("C: " + C);
                System.out.println("D: " + D);
         
                String a=A;
                String b =B;
                String c=C; 
                String d=D;
            
                String userAnswer = sc.next(); 
                ()// Simulated answer
                String correctAnswer = rs.getString("correct_option");

                if (userAnswer.equalsIgnoreCase(correctAnswer)) {
                    System.out.println("Correct!");
                } else {
                    System.out.println("Wrong! The correct answer was: " + correctAnswer);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
