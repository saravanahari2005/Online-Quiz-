package com.quizgame.db;

import com.quizgame.db.*;
import java.sql.*;

public class UserRegistration {
    public boolean registerUser(User us) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO users (username, password, score) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, us.getUsername());
            pstmt.setString(2, us.getPassword());
            pstmt.setInt(3, us.getScore());
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
