package com.quizgame.db;

import com.quizgame.db.User;
import com.quizgame.db.UserRegistration;
import com.quizgame.db.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
      
       Scanner sc = new Scanner(System.in);
       
     User us = new User();
     System.out.print("Enter the username:");
     String s = sc.next();
       us.setUsername(s);
       System.out.print("Enter the password:");
       String p = sc.next();
        us.setPassword(p);
        us.setScore(0);
        
       
        UserRegistration userReg = new UserRegistration();
        boolean success = userReg.registerUser(us);
        
        if (success) {
            System.out.println("User registered successfully!");
        }

        
        QuizGame game = new QuizGame();
        game.startQuiz();
    }
}
